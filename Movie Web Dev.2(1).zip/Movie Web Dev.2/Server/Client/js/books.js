/*global angular  */

/* we 'inject' the ngRoute module into our app. This makes the routing functionality to be available to our app. */
var myApp = angular.module('myApp', ['ngRoute'])	//NB: ngRoute module for routing and deeplinking services and directives
      const APIKEY='69f971b4bd3d8a52faedb289fa6b6d12'
/* the config function takes an array. */
myApp.config( ['$routeProvider', function($routeProvider) {
  $routeProvider
    .when('/search', {
		  templateUrl: 'templates/search.html',
      controller: 'searchController'
		})
    .when('/detail/:id', {
      templateUrl: 'templates/detail.html',
      controller: 'detailController'
    })
    .when('/favourites', {
		  templateUrl: 'templates/favourites.html',
      controller: 'favouritesController'
		})
		.otherwise({
		  redirectTo: 'search'
		})
	}])


myApp.controller('searchController', function($scope, $http) {
  $scope.message = 'Movie Search Page'
  $scope.search = function($event) {
    console.log('search()')
    if ($event.which == 13) { // enter key presses
      var search = $scope.searchTerm
      console.log(search)
      //var url = 'https://api.themoviedb.org/3/search/movie?api_key='+APIKEY+'&language=en-US&query='+search+'&page=1&include_adult=false'
      
      var url = 'https://test-ganhunter.c9users.io/movies?q='+search
      $http.get(url).success(function(response) {
        console.log(response)
        if(response.data)
        $scope.books = response.data
        else if(response.results)
        $scope.books=response.results
        
        
        
      })
    }
  }
})

myApp.controller('detailController', function($scope, $routeParams, $http) {
  $scope.message = 'Movie Detail Page'
  $scope.id = $routeParams.id

  var url = 'https://api.themoviedb.org/3/movie/'+ $scope.id+'?api_key='+APIKEY+'&language=en-US' 
  $http.get(url).success(function(rspMovie) {
    console.log("found Movie" + $scope.id)
    $scope.book = {}
    $scope.book.title = rspMovie.title
    $scope.book.summary = rspMovie.overview
    $scope.book.stars = rspMovie.vote_average
    $scope.book.poster = 'http://image.tmdb.org/t/p/w185/'+ rspMovie.poster_path
  })

  $scope.addToFavourites = function(id, title) {
    console.log('adding: '+id+' to favourites.')
    localStorage.setItem(id, title)
  }
})

myApp.controller('favouritesController', function($scope) {
  console.log('fav controller')
  $scope.message = 'Favourited Movie Page'
  var init = function() {
    console.log('Get Movies')
    var items = new Array();		//alt: = []; for blank array obj
    //for (var key in localStorage) {	//for-in will include key, getItem, setItem, removeItem, clear & length
    for(var i = 0; i < localStorage.length; i++) {
    	var key = localStorage.key(i);	//native methods are ignored
    	var obj = {};
    	//items.push( {key: localStorage.getItem(key)} )  //TRY1 {key: ...} forced to hardcode key
    	//items.push(obj[key] = localStorage.getItem(key))	//TRY2 {dym-key: ...} hard to code in <ng-repeat>
    	items.push({id: key, title:localStorage.getItem(key)})  //TRY3 OK
      //alt: items[key] = localStorage[key]
    }
    console.log(items)
    $scope.books = items
  }
  init()

  $scope.delete = function(id) {
  	localStorage.clear()
    console.log('deleting id '+id)
  }
  $scope.deleteAll = function(){ localStorage.clear(); init();}
})
